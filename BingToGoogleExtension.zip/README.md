# BingToGoogleExtension
A Google Chrome extension that allows you to easily search google for what you just binged.
